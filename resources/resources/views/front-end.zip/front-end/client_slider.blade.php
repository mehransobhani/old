<div class="our-clients">
    <div class="slider-items-products">
        <div id="our-clients-slider" class="product-flexslider hidden-buttons">
            <div class="slider-items slider-width-col6">

                <!-- Item -->
                <div class="item"> <a href="#"><img src="{{asset('images/front-end/clients/brand1.png')}}" alt="Image"></a> </div>
                <!-- End Item -->

                <!-- Item -->
                <div class="item"> <a href="#"><img src="{{asset('images/front-end/clients/brand2.png')}}" alt="Image"></a> </div>
                <!-- End Item -->

                <!-- Item -->
                <div class="item"> <a href="#"><img src="{{asset('images/front-end/clients/brand3.png')}}" alt="Image"></a> </div>
                <!-- End Item -->

                <!-- Item -->
                <div class="item"> <a href="#"><img src="{{asset('images/front-end/clients/brand4.png')}}" alt="Image"></a> </div>
                <!-- End Item -->
                <!-- Item -->
                <div class="item"> <a href="#"><img src="{{asset('images/front-end/clients/brand5.png')}}" alt="Image"></a> </div>
                <!-- End Item -->
                <!-- Item -->
                <div class="item"> <a href="#"><img src="{{asset('images/front-end/clients/brand6.png')}}" alt="Image"></a> </div>
                <!-- End Item -->
                <!-- Item -->
                <div class="item"> <a href="#"><img src="{{asset('images/front-end/clients/brand7.png')}}" alt="Image"></a> </div>
                <!-- End Item -->
                <!-- Item -->
                <div class="item"> <a href="#"><img src="{{asset('images/front-end/clients/0001.png')}}" alt="Image"></a> </div>
                <!-- End Item -->
                <!-- Item -->
                <div class="item"> <a href="#"><img src="{{asset('images/front-end/clients/0002.png')}}" alt="Image"></a> </div>
                <!-- End Item -->
                <!-- Item -->
                <div class="item"> <a href="#"><img src="{{asset('images/front-end/clients/0003.png')}}" alt="Image"></a> </div>
                <!-- End Item -->
                <!-- Item -->
                <div class="item"> <a href="#"><img src="{{asset('images/front-end/clients/0004.png')}}" alt="Image"></a> </div>
                <!-- End Item -->
                <!-- Item -->
                <div class="item"> <a href="#"><img src="{{asset('images/front-end/clients/0005.png')}}" alt="Image"></a> </div>
                <!-- End Item -->
                <!-- Item -->
                <div class="item"> <a href="#"><img src="{{asset('images/front-end/clients/0006.png')}}" alt="Image"></a> </div>
                <!-- End Item -->
                <!-- Item -->
                <div class="item"> <a href="#"><img src="{{asset('images/front-end/clients/0007.png')}}" alt="Image"></a> </div>
                <!-- End Item -->
                <!-- Item -->
                <div class="item"> <a href="#"><img src="{{asset('images/front-end/clients/0008.png')}}" alt="Image"></a> </div>
                <!-- End Item -->
                <!-- Item -->
                <div class="item"> <a href="#"><img src="{{asset('images/front-end/clients/0009.png')}}" alt="Image"></a> </div>
                <!-- End Item -->
                <!-- Item -->
                <div class="item"> <a href="#"><img src="{{asset('images/front-end/clients/0010.png')}}" alt="Image"></a> </div>
                <!-- End Item -->
                <!-- Item -->
                <div class="item"> <a href="#"><img src="{{asset('images/front-end/clients/0011.png')}}" alt="Image"></a> </div>
                <!-- End Item -->
                <!-- Item -->
                <div class="item"> <a href="#"><img src="{{asset('images/front-end/clients/0012.png')}}" alt="Image"></a> </div>
                <!-- End Item -->

            </div>
        </div>
    </div>
</div>