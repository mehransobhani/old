<div class="jtv-service-area">

    <div class="container">

        <div class="row">

            <div class="col-lg-4 col-sm-4 col-xs-12">

                <div class="jtv-service">

                    <div class="ser-icon"> <i class="fa fa-truck flip-horizontal"></i> </div>

                    <div class="service-content">

                        <h5>FREE SHIPPING WORLDWIDE </h5>

                        <p>free ship-on oder over $299.00</p>

                    </div>

                </div>

            </div>

            <div class="col-lg-4 col-sm-4 col-xs-12">

                <div class="jtv-service">

                    <div class="ser-icon"> <i class="fa fa-mail-forward"></i> </div>

                    <div class="service-content">

                        <h5>MONEY BACK GUARATEE! </h5>

                        <p>30 days money back guarantee!</p>

                    </div>

                </div>

            </div>

            <div class="col-lg-4 col-sm-4 col-xs-12">

                <div class="jtv-service">

                    <div class="ser-icon"> <i class="fa fa-comments flip-horizontal"></i> </div>

                    <div class="service-content">

                        <h5>24/7 CUSTOMER SERVICE </h5>

                        <p>We support online 24 hours a day</p>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>