<div class="container">
    <div class="row">
        <div class="col-sm-4 col-xs-12">
            <div class="jtv-banner-box banner-inner">
                <div class="image"><a class="jtv-banner-opacity" href="{{$siteBanners['top_1']['url']}}"><img
                                src="{{asset('upload/'.$siteBanners['top_1']['img'])}}" alt=""></a></div>
                {{--<div class="jtv-content-text">
                    <h3 class="title">{{$siteBanners['top_1']['title']}}</h3>
                    <span class="sub-title">{{$siteBanners['top_1']['descriptions']}}</span> <a href="{{$siteBanners['top_1']['url']}}" class="button">اطلاعات
                        بیشتر</a>
                </div>--}}
            </div>
        </div>
        <div class="col-sm-5 col-xs-12">
            <div class="jtv-banner-box">
                <div class="image"><a class="jtv-banner-opacity" href="{{$siteBanners['top_2']['url']}}"><img
                                src="{{asset('upload/'.$siteBanners['top_2']['img'])}}" alt=""></a></div>
                {{--<div class="jtv-content-text">
                    <h3 class="title">{{$siteBanners['top_2']['title']}}</h3>
                    <span class="sub-title">{{$siteBanners['top_2']['descriptions']}}</span> <a href="{{$siteBanners['top_2']['url']}}" class="button">اطلاعات
                        بیشتر</a>
                </div>--}}
            </div>
        </div>
        <div class="col-sm-3 col-xs-12">
            <div class="jtv-banner-box banner-inner">
                <div class="image"><a class="jtv-banner-opacity" href="{{$siteBanners['top_3']['url']}}"><img
                                src="{{asset('upload/'.$siteBanners['top_3']['img'])}}" alt=""></a></div>
                <div class="jtv-content-text">
                    <h3 class="title">{{$siteBanners['top_3']['title']}}</h3>
                </div>
            </div>
            <div class="jtv-banner-box banner-inner">
                <div class="image"><a class="jtv-banner-opacity" href="{{$siteBanners['top_4']['url']}}"><img
                                src="{{asset('upload/'.$siteBanners['top_4']['img'])}}" alt=""></a></div>
                <div class="jtv-content-text">
                    <h3 class="title">{{$siteBanners['top_4']['title']}}</h3>
                </div>
            </div>
        </div>
    </div>
</div>