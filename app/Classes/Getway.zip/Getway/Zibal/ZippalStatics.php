<?php
namespace App\Classes\Getway\Zibal;

class ZippalStatics
{
    public static $BASE_URL='https://gateway.zibal.ir/v1/';
    public static $merchant='656ad23ea9a498000a446e19';
    public static $callbackUrl='https://tajziland.com/payment/callback';
}
