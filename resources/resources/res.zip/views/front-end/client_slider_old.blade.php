<div class="our-clients">
    <div class="slider-items-products">
        <div id="our-clients-slider" class="product-flexslider hidden-buttons">
            <div class="slider-items slider-width-col6">

                <!-- Item -->
                <div class="item"><a href="#"><img src="images/front-end/brand1.png"
                                                   alt="Image"></a> <a
                            href="#"><img src="images/front-end/brand2.png" alt="Image"></a></div>
                <!-- End Item -->

                <!-- Item -->
                <div class="item"><a href="#"><img src="images/front-end/brand3.png"
                                                   alt="Image"></a> <a
                            href="#"><img src="images/front-end/brand4.png" alt="Image"></a></div>
                <!-- End Item -->

                <!-- Item -->
                <div class="item"><a href="#"><img src="images/front-end/brand5.png"
                                                   alt="Image"></a> <a
                            href="#"><img src="images/front-end/brand6.png" alt="Image"></a></div>
                <!-- End Item -->

                <!-- Item -->
                <div class="item"><a href="#"><img src="images/front-end/brand7.png"
                                                   alt="Image"></a> <a
                            href="#"><img src="images/front-end/brand3.png" alt="Image"></a></div>
                <!-- End Item -->

            </div>
        </div>
    </div>
</div>