<div class="video_intro">
    <video controls>
        <source src="{{asset('video/intro_video.mp4')}}" type="video/mp4">
        Your browser does not support HTML5 video.
    </video>
</div>