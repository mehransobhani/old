<div class="top-search">
	<div id="search">
		<form>
			<div class="input-group">
				{{--<select class="cate-dropdown" name="category_id">
					<option>All Categories</option>
					<option>women</option>
					<option>&nbsp;&nbsp;&nbsp;Accessories</option>
					<option>&nbsp;&nbsp;&nbsp;Dresses</option>
					<option>&nbsp;&nbsp;&nbsp;Top</option>
					<option>&nbsp;&nbsp;&nbsp;Handbags</option>
					<option>&nbsp;&nbsp;&nbsp;Shoes</option>
					<option>&nbsp;&nbsp;&nbsp;Clothing</option>
					<option>Men</option>
					<option>Electronics</option>
					<option>&nbsp;&nbsp;&nbsp;Mobiles</option>
					<option>&nbsp;&nbsp;&nbsp;Music &amp; Audio</option>
				</select>--}}
				<input type="text" class="form-control" placeholder="جست و جو" name="search" id="productSearchTerm">
				<button class="btn-search" type="button"><i class="fa fa-search"></i></button>
			</div>
		</form>
	</div>
</div>