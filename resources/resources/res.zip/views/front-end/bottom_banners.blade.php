<div class="bottom-banner-section">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-4"><a href="{{$siteBanners['bottom_right']['url']}}" class="bottom-banner-img"><img
                            src="{{asset('upload/'.$siteBanners['bottom_right']['img'])}}" alt="bottom banner"> <span
                            class="banner-overly"></span>
                    <div class="bottom-img-info">
                        <h3>{{$siteBanners['bottom_right']['title']}}</h3>
                        <h6>{{$siteBanners['bottom_right']['descriptions']}}</h6>
                        <span class="shop-now-btn">جزئیات بیشتر</span></div>
                </a></div>
            <div class="col-md-8 col-sm-8"><a href="{{$siteBanners['bottom_left']['url']}}" class="bottom-banner-img last"><img
                            src="{{asset('upload/'.$siteBanners['bottom_left']['img'])}}" alt="bottom banner"> <span
                            class="banner-overly last"></span>
                    <div class="bottom-img-info last">
                        <h3>{{$siteBanners['bottom_left']['title']}}</h3>
                        <h6>{{$siteBanners['bottom_left']['descriptions']}}</h6>
                        <span class="shop-now-btn">جزئیات بیشتر</span></div>
                </a></div>
        </div>
    </div>
</div>