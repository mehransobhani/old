<span>پیام جدیدی برای شما ارسال شده است</span>
<br>
<span>از طرف : </span>
<span>{{$email->name}}</span>
<br>
<span>آدرس پست الکترونیکی : </span>
<span>{{$email->email}}</span>
<br>
<span>شماره موبایل : </span>
<span>{{$email->phone}}</span>
<br>
<span>متن پیام : </span>
<span>{{$email->message}}</span>