<div class="testimonials">
    <div class="slider-items-products">
        <div id="testimonials-slider" class="product-flexslider hidden-buttons home-testimonials">
            <div class="slider-items slider-width-col4 ">
                <div class="holder">
                    <p>تجهیز لند یک فروشگاه بروز و کامل بوده که با خرید از آن توانستیم صرفه جویی اقتصادی زیادی را در تجهیز فست فود خود انجام داده و با خدمات پس از فروش با کادری مجرب و با اخلاق حرفه ای به تمامی خواسته های مان رسیدیم. </p>
                    <div class="thumb"><img src="images/front-end/testimonials-img2.jpg"
                                            alt="testimonials img"></div>
                    <strong class="name">محمد رزاقی</strong> <strong class="designation">مدیر فست فود مه راد</strong></div>
                <div class="holder">
                    <p>یخچال های صنعتی تجهیزلند بسیار به صرفه و اقتصادی بوده و با خرید آنها هم از ظرفیت بالا و هم از توان مصرفی فوق العاده آن راضی بودیم و در نهایت بهترین انتخاب را جلوی پایمان گذاشتند.</p>
                    <div class="thumb"><img src="images/front-end/testimonials-img1.jpg"
                                            alt="testimonials img"></div>
                    <strong class="name">فریبا سلطانی</strong> <strong class="designation">مدیر کافی شاپ ستاره</strong></div>
                {{--<div class="holder">
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                        eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
                        minim veniam, quis nostrud. </p>
                    <div class="thumb"><img src="images/front-end/testimonials-img2.jpg"
                                            alt="testimonials img"></div>
                    <strong class="name">John Doe</strong> <strong class="designation">CEO, ABC
                        Softwear</strong></div>
                <div class="holder">
                    <p>sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
                        minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip
                        ex ea commodo consequat.</p>
                    <div class="thumb"><img src="images/front-end/testimonials-img4.jpg"
                                            alt="testimonials img"></div>
                    <strong class="name">Vince Roy</strong> <strong class="designation">CEO, XYZ
                        Softwear</strong></div>--}}
            </div>
        </div>
    </div>
</div>